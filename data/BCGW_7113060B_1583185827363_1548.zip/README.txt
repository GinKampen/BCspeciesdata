By downloading these data products, you have agreed to the license terms and 
conditions as set out in each Geographic Data Discovery Service metadata record.
Please ensure you understand the licenses or contact that Data Custodian for
more information.

For further notices about download issues, please refer to
https://www2.gov.bc.ca/gov/content?id=DB8E862A038E46F3BABE0321631C8486

If you need additional information about the Data Distribution Serive you can
email an actual person at NRSApplications@gov.bc.ca 

